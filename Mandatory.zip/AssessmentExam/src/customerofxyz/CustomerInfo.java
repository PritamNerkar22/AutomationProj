package customerofxyz;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class CustomerInfo extends MandatoryOne {
	
	@Test
	public static void AddCust() throws InterruptedException, EncryptedDocumentException, IOException
	{
		String [][] testData = ReadXLSData.getData();
		for (int i = 0; i < testData.length; i++)
		{
		
		driver.findElement(
				By.xpath("//input[@placeholder='First Name']")).sendKeys(testData[i][0].trim());
		driver.findElement(
				By.xpath("//input[@placeholder='Last Name']")).sendKeys(testData[i][1].trim());
		driver.findElement(
				By.xpath("//input[@placeholder='Post Code']")).sendKeys(testData[i][2].trim());

		Thread.sleep(4000);
		driver.findElement(By.xpath("//button[text()='Add Customer']")).click();
		Thread.sleep(4000);
		driver.switchTo().alert().accept();
		}
		driver.findElement(By.xpath("//button[contains(text(),'Customers')]")).click();
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,1000)");
		
		for (int i = 0; i < testData.length; i++)
		{
		driver.findElement(By.xpath("//td[contains(text(),'"+testData[i][0].trim()+"')]/following-sibling::td[contains(text(),'"+testData[i][1].trim()+"')]/following-sibling::td[contains(text(),'"+testData[i][2].trim()+"')]")).isDisplayed();
		System.out.println("Varification passed");
		}
		
		driver.findElement(By.xpath("//td[contains(text(),'Jackson')]/following-sibling::td[contains(text(),'Frank')]/following-sibling::td[contains(text(),'L789C349')]/following-sibling::td/button[text()='Delete']")).click();
		driver.findElement(By.xpath("//td[contains(text(),'Christopher')]/following-sibling::td[contains(text(),'Connely')]/following-sibling::td[contains(text(),'L789C349')]/following-sibling::td/button[text()='Delete']")).click();
	}


}
