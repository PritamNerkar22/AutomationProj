package customerofxyz;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class MandatoryOne {
	public static WebDriver driver;

	@BeforeMethod
	public void main() throws EncryptedDocumentException, IOException, InterruptedException {

		// Launching the browser
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\DriverFile\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();

		// Opening below mentioned URL
		driver.get("https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// click on Bank Manager Login button
		driver.findElement(By.xpath("//button[text()='Bank Manager Login']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Click on Add customer button
		driver.findElement(By.xpath("//button[@class='btn btn-lg tab'][1]")).click();

		// Creating class object and passing the testdata excel sheet name

	}
	@AfterMethod
	public void closebrow()
	{
		driver.close();
		System.out.println("Browser closed successfully");
	}
	
	
}